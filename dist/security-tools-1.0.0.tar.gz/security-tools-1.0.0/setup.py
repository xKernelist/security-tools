from setuptools import setup, find_packages

setup(
    name='security-tools',
    version='1.0.0',
    packages=find_packages(),
    author='kernelist',
    author_email='msefaercan@gmail.com',
    description='A simple security tools module for message encryption and decryption.',
    url='https://github.com/xkernelist/security-tools',
)
